package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	@Autowired
	OAuth2RestTemplate restTemplate;

	@GetMapping("/product")
	public Product getName() {
		return new Product("Milk", 5.2);
	}

	@GetMapping("/salary")
	public String getSalary() {
		return restTemplate.getForObject("http://localhost:8091/salary", String.class);
	}


	@GetMapping("/employee")
	public EmployeeDTO getPhone() {
		return restTemplate.getForObject("http://localhost:8092/employee", EmployeeDTO.class);
	}
}

