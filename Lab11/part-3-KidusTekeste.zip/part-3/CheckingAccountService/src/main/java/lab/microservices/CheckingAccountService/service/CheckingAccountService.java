package lab.microservices.CheckingAccountService.service;

import lab.microservices.CheckingAccountService.data.AccountRepository;
import lab.microservices.CheckingAccountService.domain.Account;
import lab.microservices.CheckingAccountService.domain.AccountEntry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CheckingAccountService {

    @Autowired
    AccountRepository accountRepository;

    public void createAccount(Account account){
        accountRepository.save(account);
    }

    public void withdraw(Long accountNumber, AccountEntry entry){
        Account account = accountRepository.findAccountByAccountNumber(accountNumber);
        if(account!=null){
            account.addEntry(entry);
            accountRepository.save(account);
        }
    }

    public void deposit(Long accountNumber, AccountEntry entry){
        Account account = accountRepository.findAccountByAccountNumber(accountNumber);
        if(account!=null){
            account.addEntry(entry);
            accountRepository.save(account);
        }
    }
}
