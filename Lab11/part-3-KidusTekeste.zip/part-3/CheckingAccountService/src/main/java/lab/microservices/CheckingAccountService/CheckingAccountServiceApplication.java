package lab.microservices.CheckingAccountService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheckingAccountServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CheckingAccountServiceApplication.class, args);
	}

}
