package lab.microservices.CheckingAccountService.domain;

import java.util.ArrayList;
import java.util.List;

public class Account {
    private String accountOwner;
    private Long accountNumber;
    private List<AccountEntry> accountEntries = new ArrayList<>();

    public Account(String accountOwner, Long accountNumber, List<AccountEntry> accountEntries) {
        this.accountOwner = accountOwner;
        this.accountNumber = accountNumber;
        this.accountEntries.addAll(accountEntries);
    }

    public Long getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(Long accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountOwner() {
        return accountOwner;
    }

    public void setAccountOwner(String accountOwner) {
        this.accountOwner = accountOwner;
    }

    public List<AccountEntry> getAccountEntries() {
        return accountEntries;
    }

    public void addEntry(AccountEntry accountEntry) {
        this.accountEntries.add(accountEntry);
    }
}
