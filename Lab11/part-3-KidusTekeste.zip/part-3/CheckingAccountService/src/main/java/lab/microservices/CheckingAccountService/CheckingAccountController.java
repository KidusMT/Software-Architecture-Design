package lab.microservices.CheckingAccountService;

import lab.microservices.CheckingAccountService.domain.Account;
import lab.microservices.CheckingAccountService.service.CheckingAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CheckingAccountController {
    @Autowired
    CheckingAccountService accountService;

    @PostMapping("/checking")
    public void createAccount(@RequestBody Account account) {
        accountService.createAccount(account);
    }
}
