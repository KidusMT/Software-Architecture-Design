package lab.microservices.SavingAccountService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SavingAccountServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
