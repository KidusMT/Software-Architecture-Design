package lab.microservices.SavingAccountService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SavingAccountServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SavingAccountServiceApplication.class, args);
	}

}
