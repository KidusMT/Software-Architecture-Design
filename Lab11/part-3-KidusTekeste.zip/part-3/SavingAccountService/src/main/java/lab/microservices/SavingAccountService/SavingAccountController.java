package lab.microservices.SavingAccountService;

import lab.microservices.SavingAccountService.domain.Account;
import lab.microservices.SavingAccountService.service.SavingAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SavingAccountController {
    @Autowired
    SavingAccountService accountService;

    @PostMapping("/checking")
    public void createAccount(@RequestBody Account account) {
        accountService.createAccount(account);
    }
}
