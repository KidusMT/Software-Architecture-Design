package lab.microservices.SavingAccountService.service;

import lab.microservices.SavingAccountService.data.AccountRepository;
import lab.microservices.SavingAccountService.domain.Account;
import lab.microservices.SavingAccountService.domain.AccountEntry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SavingAccountService {

    @Autowired
    AccountRepository accountRepository;

    public void createAccount(Account account){
        accountRepository.save(account);
    }

    public void withdraw(Long accountNumber, AccountEntry entry){
        Account account = accountRepository.findAccountByAccountNumber(accountNumber);
        if(account!=null){
            account.addEntry(entry);
            accountRepository.save(account);
        }
    }

    public void deposit(Long accountNumber, AccountEntry entry){
        Account account = accountRepository.findAccountByAccountNumber(accountNumber);
        if(account!=null){
            account.addEntry(entry);
            accountRepository.save(account);
        }
    }
}
