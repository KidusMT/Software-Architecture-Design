package customers.repository;

import customers.domain.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentRepository extends MongoRepository<Student, Integer> {
    Student findByPhoneNumber(String phone);

    Student findByName(String name);

    @Query("{'address.city' : ?0}")
    List<Student> findStudentsByAddress_City(String city);

}




