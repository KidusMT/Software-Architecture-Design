package repositories;

import domain.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {
    Student findByPhoneNumber(String phone);

    Student findByName(String name);

    @Query("select c from Student c where c.address.city= :city")
    List<Student> findStudentsByAddress_City(String city);

}




