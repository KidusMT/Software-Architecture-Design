package app;

import domain.Address;
import domain.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import repositories.StudentRepository;

import java.util.List;

@SpringBootApplication
@EnableJpaRepositories("repositories")
@EntityScan("domain") 
public class StudentApplication implements CommandLineRunner{

	@Autowired
	StudentRepository studentRepository;

	public static void main(String[] args) {
		SpringApplication.run(StudentApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		// create students
		Student student1 = new Student(111,"Tom Hanks", "hanks@acme.com", "1622341678");
		Address faifield = new Address("1000 N. 4th St.", "Faifield", "52557");
		student1.setAddress(faifield);
		studentRepository.save(student1);

		Student student2 = new Student(112,"Tom Cruise", "tom@acme.com", "2622341678");
		Address ottomua = new Address("Ottomua St.", "Ottomua", "52557");
		student2.setAddress(ottomua);
		studentRepository.save(student2);

		Student student3 = new Student(113,"Will Smith", "will@acme.com", "3622341678");
		Address burlington = new Address("Burlington St.", "Burlington", "52557");
		student3.setAddress(burlington);
		studentRepository.save(student3);

		Student student4 = new Student(114,"Brad Pit", "brad@acme.com", "4622341678");
		Address nevada = new Address("Nevada St.", "Nevada", "52557");
		student4.setAddress(nevada);
		studentRepository.save(student4);

		Student student5 = new Student(115,"Kidus Tekeste", "kidus@acme.com", "5622341678");
		student5.setAddress(faifield);
		studentRepository.save(student5);

		// get students
		System.out.println("-----------All Students ----------------");
		System.out.println(studentRepository.findAll());

		System.out.println("-----------find by Name = \"Kidus Tekeste\" ----------------");
		System.out.println(studentRepository.findByName("Kidus Tekeste"));

		System.out.println("-----------find by PhoneNumber = \"4622341678\" ----------------");
		System.out.println(studentRepository.findByPhoneNumber("4622341678"));

		System.out.println("-----------find students with a certain city = \"Faifield\" ----------------");
		System.out.println(studentRepository.findStudentsByAddress_City("Faifield"));

		System.out.println("\n-----------find students with a certain city ----------------");
		List<Student> students = studentRepository.findStudentsByAddress_City("Faifield");
		students.forEach(student -> System.out.println(student));
	}

}
