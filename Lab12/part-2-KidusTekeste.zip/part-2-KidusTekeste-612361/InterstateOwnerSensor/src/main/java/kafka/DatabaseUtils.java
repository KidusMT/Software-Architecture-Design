package kafka;

import java.util.HashMap;

public class DatabaseUtils {
    private static final HashMap<String, String> carOwnersRegistry = new HashMap<>();

    static {
        carOwnersRegistry.put("AA1", "John Doe");
        carOwnersRegistry.put("BB1", "Will Smith");
        carOwnersRegistry.put("CC1", "Brad Pit");
        carOwnersRegistry.put("EE1", "Ronaldo Christian");
        carOwnersRegistry.put("FF1", "Terry Henry");
        carOwnersRegistry.put("GA1", "Philip Daniel");
        carOwnersRegistry.put("FB1", "Michael Todd");
        carOwnersRegistry.put("FA1", "Smith Alex");
        carOwnersRegistry.put("FG1", "Johnathan Mclean");
        carOwnersRegistry.put("AS1", "Elda Palumbo");
        carOwnersRegistry.put("BS1", "Pacifico Giordano");
        carOwnersRegistry.put("CS1", "Sig. Avide Guerra");
        carOwnersRegistry.put("ES1", "Yago Amato");
        carOwnersRegistry.put("FS1", "Eustachio Messina");
        carOwnersRegistry.put("GS1", "Dott. Violante Lombardo");
        carOwnersRegistry.put("FBS", "Sig. Alighieri Monti");
        carOwnersRegistry.put("FAS", "Costanzo Costa");
        carOwnersRegistry.put("FGS", "Nazzareno Barbieri");
    }

    public static String findByLicensePlate(String name){
        return carOwnersRegistry.get(name);
    }

}
