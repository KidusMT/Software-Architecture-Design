package kafka;

public class FeeRecord {
    public String licencePlate;
    public String owner;
    public int speed;
    public double fee;

    public FeeRecord(String licencePlate, int speed, String owner, double fee) {
        this.licencePlate = licencePlate;
        this.owner = owner;
        this.speed = speed;
        this.fee = fee;
    }

    public String toString() {
        return licencePlate+" "+speed+" "+owner+" "+fee;
    }

    public FeeRecord() {
    }

    public double getFee() {
        return fee;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getLicencePlate() {
        return licencePlate;
    }

    public void setLicencePlate(String licencePlate) {
        this.licencePlate = licencePlate;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
