package kafka;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class Receiver {
    @Autowired
    private Sender sender;

    @KafkaListener(topics = {"OwnerTopic"})
    public void receive(@Payload OwnerRecord ownerRecord,
                        @Headers MessageHeaders headers) {

//        72 – 77 miles/hour = $ 25
//        77 - 82 miles/hour = $ 45
//        82 – 90 miles/hour = $ 80
//        > 90 miles/hour = $ 125
        double fee = 0.0;
        if (ownerRecord.speed >= 72 && ownerRecord.speed < 77) {
            fee = 25;
        } else if (ownerRecord.speed >= 77 && ownerRecord.speed < 82) {
            fee = 45;
        } else if (ownerRecord.speed >= 82 && ownerRecord.speed < 90) {
            fee = 80;
        } else if (ownerRecord.speed >= 90) {
            fee = 125;
        }
        FeeRecord feeRecord = new FeeRecord(ownerRecord.licencePlate, ownerRecord.speed, ownerRecord.owner, fee);
        System.out.printf("license plate: %s, owner info: %s, speed: %s, amount of the fee: $ %s \n",
                feeRecord.licencePlate, feeRecord.owner, feeRecord.speed, feeRecord.fee);
        sender.send("FeeTopic", feeRecord);
    }

}