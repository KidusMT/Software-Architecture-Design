package kafka;

public class OwnerRecord {
    public String licencePlate;
    public String owner;
    public int speed;

    public OwnerRecord(String licencePlate, int speed, String owner) {
        this.licencePlate = licencePlate;
        this.owner = owner;
        this.speed = speed;
    }

    public OwnerRecord() {
    }

    public String toString() {
        return licencePlate+" "+speed+" "+owner;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getLicencePlate() {
        return licencePlate;
    }

    public void setLicencePlate(String licencePlate) {
        this.licencePlate = licencePlate;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
